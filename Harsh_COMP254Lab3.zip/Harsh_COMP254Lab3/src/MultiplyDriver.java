public class MultiplyDriver {
    public static void main(String[] args) {
        System.out.println(RecursiveMultiplication.multiplyRecursion(12, 18));
    }
}